interface Result {
    Id: number;
    QuizId: number;
    Text: string;
    MinValue?: number;
    MaxValue?: number;
}
